import sys
from .fhir_mcp_service import main

if __name__ == "__main__":
    # Call the main function and exit with its return code
    sys.exit(main())
